#include <iostream>

// used with custom type
struct mytype
{
    constexpr mytype (unsigned long long m) : m(m){}
    unsigned long long m;
};

constexpr mytype operator "" _mytype(unsigned long long n)
{
    return mytype(n);
}

int main()
{
    constexpr mytype y = 123_mytype;
    std::cout << y.m << '\n';

    return 0;
}
