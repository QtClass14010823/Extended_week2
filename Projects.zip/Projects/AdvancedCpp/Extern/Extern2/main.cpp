// As we are importing the file and henceforth the
// defination
#include "somefile.h"

// Declaring the same variable
extern int var;

int main(void)
{
    var = 10;
    return 0;
}
